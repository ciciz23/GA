// Get DOM object city-form ID, which is on the form element

const citipix = document.querySelector("#citipix-form");
// console.log(citipix);

const citiName = document.querySelector("#city-type");
// console.log(citiName);

citipix.addEventListener("submit", function (event) {
  //This stops the page from re-loading.//
  event.preventDefault();
  // console.dir(citiName);
  // console.log(citiName.value);

  // Research .trim and .toLowerCase. add them to citiNameValue.Might need to give a second const in for citiNameValue. //
  const citiNameValue = citiName.value.toLowerCase();
  if (citiNameValue === "newyork" || "new york" || "nyc") {
    document.querySelector("#citipix-form").classList.add("nyc");
    console.log("Hello New York!");
    // Add classname to body to change background. //
  } else if (citiNameValue === "san" || "san francisco") {
    document.querySelector("#citipix-form").classList.add("sf");
    console.log("Hello sf!");
  } else if (citiNameValue === "la" || "las vagas") {
    document.querySelector("#citipix-form").classList.add("la");
    console.log("Hello Las Vagas!");
  } else if (citiNameValue === "austin") {
    document.querySelector("#citipix-form").classList.add("austin");
    console.log("Hello Austin!");
  } else if (citiNameValue === "sydney") {
    document.querySelector("#citipix-form").classList.add("sydney");
    console.log("Helllo Sydney!");
  } else {
    console.log("Please try a different city!");
    //Look into a way to clear all the class names. //
  }
  citipix.reset();
});

// True form submissions go to a backend service, but we want to handle things in the front-end. How can we do this?

// Get the text input fields values with .value on the input - but how exactly?

// You always want to scan and clean data when you get it from the browser, think about .trim and .toLowerCase - this will make your conditional detection more consistent

// This about conditional logic. We want to check through each possible input a user gives us to make this work properly. Think about conditional statements, going through the list of possible city options.

// If a user gives us 'Austin' versus 'austin' - how can we make those point to the same background?

// We know we want to change the background on the page by switching classes. But how do we replace one class with another using JS???
